#!/bin/bash
sudo LD_LIBRARY_PATH=. ldconfig
sudo LD_LIBRARY_PATH=. ./rc_test r
