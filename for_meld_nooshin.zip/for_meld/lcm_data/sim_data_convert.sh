#!/bin/bash
./../scripts/log_convert.sh lcm_log/sim_data matlab_log/sim_data
