/*! @file sim_utilities.cpp
 *  @brief Utility functions that exist only in the simulator
 */

#include "sim_utilities.h"
