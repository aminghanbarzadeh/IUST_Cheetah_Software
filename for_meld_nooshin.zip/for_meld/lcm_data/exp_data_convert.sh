#!/bin/bash
./../scripts/log_convert.sh lcm_log/$1 matlab_log/$2
